<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
  <link rel="stylesheet" href="CSS/login.css">
</head>

<body>
  <div class="container">
    <form class="login-form">
      <div class="login-icon text-center">
        <img src="imgs/login-icon.png" alt="" />
      </div>

      <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">Email address</label>
        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your email" />
      </div>
      <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Password</label>
        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Enter your Password" />
      </div>
      <button type="submit" class="btn login-form-btn">Login</button>
      <div class="signup-redirect text-center">
        <span class="login-text">Don't Have An Account? </span>
        <a href="" class="signup-link">Sign up</a>
      </div>
    </form>
  </div>
  <script src="JS/code.jquery.com_jquery-3.7.0.min.js"></script>
  <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>