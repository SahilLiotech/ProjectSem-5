<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Bootstrap 5 Side Bar Navigation</title>
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
  <script src="JS/code.jquery.com_jquery-3.7.0.min.js"></script>
  <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="CSS/Style.css">
</head>

<body>
  <div class="d-flex flex-row">
    <?php include('sidebar.php'); ?>
    <section class="container p-4 my-container">
      <div class="row dashboard-row">
        <div class="col-12 col-md-4 col-lg-3">
          <div class="card d-flex align-items-center justify-content-center">
            <div class="logo-container card-logo-container d-flex align-items-center justify-content-center">
              <img src="imgs/admin-car.png" class="logo-img" />
              <p class="card-heading">Cars</p>
            </div>
            <p class="card-detail">36</p>
          </div>
        </div>
        <div class="col-12 col-md-4 col-lg-3">
          <div class="card d-flex align-items-center justify-content-center">
            <div class="logo-container card-logo-container d-flex align-items-center justify-content-center">
              <img src="imgs/admin-bike.png" class="logo-img" />
              <p class="card-heading">Bikes</p>
            </div>
            <p class="card-detail">36</p>
          </div>
        </div>
        <div class="col-12 col-md-4 col-lg-3">
          <div class="card d-flex align-items-center justify-content-center">
            <div class="logo-container card-logo-container d-flex align-items-center justify-content-center">
              <img src="imgs/admin-scooter.png" class="logo-img" />
              <p class="card-heading">Scooter</p>
            </div>
            <p class="card-detail">36</p>
          </div>
        </div>
        <div class="col-12 col-md-4 col-lg-3">
          <div class="card d-flex align-items-center justify-content-center">
            <div class="logo-container card-logo-container d-flex align-items-center justify-content-center">
              <img src="imgs/admin-ev.png" class="logo-img" />
              <p class="card-heading">Electric Vehicles</p>
            </div>
            <p class="card-detail">36</p>
          </div>
        </div>
        <div class="col-12 col-md-4 col-lg-3">
          <div class="card d-flex align-items-center justify-content-center">
            <div class="logo-container card-logo-container d-flex align-items-center justify-content-center">
              <img src="imgs/admin-user.png" class="logo-img" />
              <p class="card-heading">Users</p>
            </div>
            <p class="card-detail">36</p>
          </div>
        </div>
        <div class="col-12 col-md-4 col-lg-3">
          <div class="card d-flex align-items-center justify-content-center">
            <div class="logo-container card-logo-container d-flex align-items-center justify-content-center">
              <img src="imgs/admin-feedback.png" class="logo-img" />
              <p class="card-heading">Feedbacks</p>
            </div>
            <p class="card-detail">36</p>
          </div>
        </div>
        <div class="col-12 col-md-4 col-lg-3">
          <div class="card d-flex align-items-center justify-content-center">
            <div class="logo-container card-logo-container d-flex align-items-center justify-content-center">
              <img src="imgs/admin-sale.png" class="logo-img" />
              <p class="card-heading">Sales</p>
            </div>
            <p class="card-detail">36</p>
          </div>
        </div>
      </div>
    </section>
  </div>
</body>

</html>