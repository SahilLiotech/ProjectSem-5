<?php
require('db.php');

if (isset($_GET['id'])) {
  $product_id = $_GET['id'];

  $sql = "SELECT * FROM scooter WHERE scooter_id = $product_id";
  $scooter_detail = $conn->query($sql);

  if ($scooter_detail->num_rows > 0) {
    $product = $scooter_detail->fetch_assoc();
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo isset($product['scooter_name']) ? $product['scooter_name'] : 'Product Detail'; ?></title>
  <link rel="stylesheet" href="CSS/style.css" />
  <link rel="stylesheet" href="CSS/login.css">
  <link rel="stylesheet" href="CSS/signup.css">
  <link rel="stylesheet" href="CSS/main.css" />
  <link rel="stylesheet" href="Bootstrap/css/bootstrap.min.css">
</head>

<body>
  <?php
  include('header.php');
  ?>

  <div class="container">
    <div class="row row-st product-container">
      <div class="col-12 col-md mt-4">
        <img src="<?php echo $product['scooter_img']; ?>" class="img-fluid product-img" width="500rem" />
      </div>
      <div class="product-detail col-12 col-md d-flex flex-column justify-content-center">
        <h2 class="product-title"><?php echo $product['scooter_name']; ?></h2>
        <p class="product-text">&#8377;<?php echo $product['scooter_price']; ?> <span>Onward</span></p>
      </div>
      <a href="#" class="btn btn-dark buy-btn">Buy Now</a>
    </div>

    <div class="row row-st feature-box">
      <h2 class="my-4">Specification</h2>
      <div class="col feature-item text-center">
        <img src="imgs/engine.png" alt="" />
        <p class="spec">Engine</p>
        <p class="spec-detail"><?php echo $product['scooter_engine']; ?></p>
      </div>
      <div class="col feature-item text-center">
        <img src="imgs/fule.png" alt="" />
        <p class="spec">Fuel Type</p>
        <p class="spec-detail"><?php echo $product['fuel_type']; ?></p>
      </div>
      <div class="col feature-item text-center">
        <img src="imgs/Kerb.png" alt="" />
        <p class="spec">Kerb Weight</p>
        <p class="spec-detail"><?php echo $product['kerb_type']; ?></p>
      </div>
      <div class="col feature-item text-center">
        <img src="imgs/meter.png" alt="" />
        <p class="spec">Mileage</p>
        <p class="spec-detail"><?php echo $product['mileage']; ?></p>
      </div>
    </div>

    <div class="row row-st description">
      <div class="col">
        <h2 class="my-4">Description</h2>
        <?php
        $content = $product['description'];

        $description = explode("\n", $content);
        foreach ($description as $desc) {
          echo '<p>' . $desc . '</p>';
        }
        ?>
      </div>
    </div>

    <div class="row procons row-st mb-4">
      <div class="col-sm-12 col-md mb-4 mb-md-0 pros">
        <h3 class="d-flex align-items-center">
          Pros<img src="imgs/correct.png" width="20rem" class="ms-2" />
        </h3>
        <ul>
          <?php
          $list = $product['pros'];

          $pros = explode("\n", $list);
          foreach ($pros as $pro) {
            echo '<li>' . $pro . '</li>';
          }
          ?>
        </ul>
      </div>

      <div class="col-sm-12 col-md cons">
        <h3 class="d-flex align-items-center">
          Cons <img src="imgs/wrong.png" alt="" width="22rem" class="ms-2" />
        </h3>
        <ul>
          <?php
          $list = $product['cons'];

          $cons = explode("\n", $list);
          foreach ($cons as $con) {
            echo '<li>' . $con . '</li>';
          }
          ?>
        </ul>
      </div>
    </div>
  </div>

  <?php
  include('footer.php');
  ?>

  <script src="JS/code.jquery.com_jquery-3.7.0.min.js"></script>
  <script src="Bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>