$(document).ready(function () {
  //this 4 are the click events for the find section which one is located into the index.php file
  //when user click on the any find-card it redirected to the that particular page using it's ID
  $("#find-car").click(function () {
    window.location.href = "cars.php";
  });
  $("#find-bike").click(function () {
    window.location.href = "bikes.php";
  });
  $("#find-scooter").click(function () {
    window.location.href = "scooters.php";
  });
  $("#find-ev").click(function () {
    window.location.href = "ev.php";
  });
});
