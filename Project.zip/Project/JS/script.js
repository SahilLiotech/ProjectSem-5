$(document).ready(function () {
  //this 4 are the click events for the find section which one is located into the index.php file
  //when user click on the any find-card it redirected to the that particular page using it's ID
  $("#find-car").click(function () {
    window.location.href = "cars.php";
  });
  $("#find-bike").click(function () {
    window.location.href = "bikes.php";
  });
  $("#find-scooter").click(function () {
    window.location.href = "scooters.php";
  });
  $("#find-ev").click(function () {
    window.location.href = "ev.php";
  });

  //Use Ajax For sent data to Login.php
  $(".login-modal-form").submit(function (e) {
    e.preventDefault();
    $.ajax({
      type: "POST",
      url: "login.php",
      data: $(this).serialize(),
      dataType: "JSON",
      success: function (response) {
        if (response["success"] == false) {
          alert(response["message"]);
        } else {
          alert(response["message"]);
          location.reload();
        }
      },
      error: function () {},
    });
  });

  //Use Ajax For sent data to register.php
  $(".signup-form").submit(function (e) {
    e.preventDefault();
    $.ajax({
      type: "POST",
      url: "register.php",
      data: $(this).serialize(),
      dataType: "JSON",
      success: function (response) {
        if (response["success"] == false) {
          alert(response["message"]);
        } else {
          alert(response["message"]);
          location.reload();
        }
      },
    });
  });

  //Use Ajax For Sent data to contact-insert.php
  $(".contact-form").submit(function (e) {
    e.preventDefault();
    $.ajax({
      type: "POST",
      url: "contact-insert.php",
      data: $(this).serialize(),
      dataType: "JSON",
      success: function (response) {
        if (response["success"] == false) {
          alert(response["message"]);
        } else {
          alert(response["message"]);
          location.reload();
        }
      },
    });
  });
});
